import { GroqProvider } from "./groqProvider.js";
import { GeminiProvider } from "./geminiProvider.js";
import { OpenRouterProvider } from "./openrouterProvider.js";

const providers = {
  groq: new GroqProvider(),
  gemini: new GeminiProvider(),
  openrouter: new OpenRouterProvider(),
};

const FALLBACK_CHAIN = ["gemini", "openrouter"];
const TITLE_CHAIN = ["gemini", "groq", "openrouter"];

export const AI_ERROR_CODES = {
  RATE_LIMITED: "RATE_LIMITED",
  PROVIDER_UNAVAILABLE: "PROVIDER_UNAVAILABLE",
};

/** Nhận diện lỗi giới hạn tốc độ / hết quota từ OpenAI SDK, Groq SDK và Google Generative AI. */
export function isRateLimitError(err) {
  if (!err) return false;
  if (err.status === 429 || err.statusCode === 429 || err.code === 429) return true;
  const text = `${err.message || ""} ${err.code || ""}`;
  return /\b429\b|rate.?limit|too many requests|quota|RESOURCE_EXHAUSTED/i.test(text);
}

export function getConfiguredProviders() {
  return Object.entries(providers)
    .filter(([, p]) => p.isConfigured())
    .map(([name]) => name);
}

export function isProviderConfigured(name) {
  return providers[name]?.isConfigured() || false;
}

export async function* streamWithFallback(messages, preferredProvider = "groq", model) {
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter((p) => p !== preferredProvider)];
  const errors = [];
  let rateLimited = false;

  for (const providerName of chain) {
    const provider = providers[providerName];
    if (!provider || !provider.isConfigured()) {
      errors.push(`${providerName}: chưa cấu hình API key`);
      continue;
    }

    try {
      let hasYielded = false;
      for await (const token of provider.streamChat(messages, providerName === preferredProvider ? model : undefined)) {
        hasYielded = true;
        yield { token, provider: providerName };
      }
      if (hasYielded) return;
      errors.push(`${providerName}: không trả về dữ liệu`);
    } catch (err) {
      console.error(`[AI Router] Nhà cung cấp "${providerName}" gặp lỗi:`, err.message);
      if (isRateLimitError(err)) rateLimited = true;
      errors.push(`${providerName}: ${err.message}`);
      continue;
    }
  }

  const error = new Error(`Tất cả nhà cung cấp AI đều gặp lỗi hoặc chưa được cấu hình. Chi tiết: ${errors.join(" | ")}`);
  error.code = rateLimited ? AI_ERROR_CODES.RATE_LIMITED : AI_ERROR_CODES.PROVIDER_UNAVAILABLE;
  throw error;
}

export async function generateConversationTitle(text) {
  const fallbackTitle = text.length > 60 ? `${text.slice(0, 57)}...` : text;

  for (const name of TITLE_CHAIN) {
    const provider = providers[name];
    if (!provider || !provider.isConfigured()) continue;
    try {
      const title = await provider.generateTitle(text);
      if (title) return title.slice(0, 120);
    } catch (err) {
      console.error(`[AI Router] Không thể tạo tiêu đề bằng "${name}":`, err.message);
    }
  }

  return fallbackTitle;
}